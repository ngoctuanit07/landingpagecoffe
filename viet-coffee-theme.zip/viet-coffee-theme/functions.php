<?php
/**
 * Viet Coffee Theme functions and definitions
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Theme setup
function viet_coffee_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'woocommerce' );
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );
    
    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'viet-coffee' ),
    ) );
    
    // Add custom image sizes if needed
    add_image_size( 'coffee-featured', 600, 600, true );
}
add_action( 'after_setup_theme', 'viet_coffee_setup' );

// Enqueue styles and scripts
function viet_coffee_scripts() {
    $style_path = get_stylesheet_directory() . '/style.css';
    wp_enqueue_style( 'viet-coffee-style', get_stylesheet_uri(), array(), file_exists($style_path) ? filemtime($style_path) : '1.1' );
    wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css' );
    wp_enqueue_style( 'google-fonts', 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Inter:wght@400;500;600&display=swap', array(), null );
    
    // Tailwind via CDN for demo - better to compile in production
    wp_enqueue_script( 'tailwind', 'https://cdn.tailwindcss.com', array(), null, false );
    
    // Use filemtime for automatic cache busting (important after JS fixes)
    $main_js_path = get_template_directory() . '/js/main.js';
    $main_js_ver  = file_exists( $main_js_path ) ? filemtime( $main_js_path ) : '1.1';
    wp_enqueue_script( 'viet-coffee-script', get_template_directory_uri() . '/js/main.js', array('jquery'), $main_js_ver, true );

    // Ensure WooCommerce cart AJAX fragments are available for mini-cart interactivity
    if ( class_exists( 'WooCommerce' ) ) {
        wp_enqueue_script( 'wc-cart-fragments' );
        // Load checkout scripts so modal checkout form works (validation, payments, etc.)
        wp_enqueue_script( 'wc-checkout' );
        wp_enqueue_script( 'wc-address-i18n' );
        wp_enqueue_script( 'wc-country-select' );

        // Force load WooCommerce's base styles. Without these the embedded checkout
        // form (rendered via shortcode in modal on non-checkout page) can be unstyled/broken.
        wp_enqueue_style( 'woocommerce-general' );
        wp_enqueue_style( 'woocommerce-layout' );
        wp_enqueue_style( 'woocommerce-smallscreen' );
    }
    
    // Localize script
    wp_localize_script( 'viet-coffee-script', 'vietCoffee', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce' => wp_create_nonce( 'viet_coffee_nonce' ),
    ) );
}
add_action( 'wp_enqueue_scripts', 'viet_coffee_scripts' );

// WooCommerce customizations
function viet_coffee_woocommerce_setup() {
    // Remove default WooCommerce wrappers if using custom
    remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
    remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
}
add_action( 'init', 'viet_coffee_woocommerce_setup' );

// Basic admin settings page
function viet_coffee_add_admin_menu() {
    add_menu_page(
        'Viet Coffee Settings',
        'Viet Coffee',
        'manage_options',
        'viet-coffee-settings',
        'viet_coffee_settings_page',
        'dashicons-coffee',
        60
    );
}
add_action( 'admin_menu', 'viet_coffee_add_admin_menu' );

function viet_coffee_settings_page() {
    $options = get_option( 'viet_coffee_options', array() );
    $featured_id = isset( $options['featured_product_id'] ) ? $options['featured_product_id'] : '';
    $imported = get_option( 'viet_coffee_demo_imported', false );
    ?>
    <div class="wrap">
        <h1>Viet Coffee Theme Settings</h1>
        <p class="description">Configure your Vietnamese coffee theme. Use the tools below to quickly populate your site with demo content.</p>

        <div style="max-width:820px; margin-top:20px;">
            <!-- Settings Form -->
            <div class="card" style="padding:20px 24px; margin-bottom:30px;">
                <h2 style="margin-top:0;">General Settings</h2>
                <form method="post" action="options.php">
                    <?php
                    settings_fields( 'viet_coffee_settings' );
                    do_settings_sections( 'viet-coffee-settings' );
                    ?>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><label for="featured_product_id">Featured Product ID</label></th>
                            <td>
                                <input type="number" id="featured_product_id" name="viet_coffee_options[featured_product_id]" value="<?php echo esc_attr( $featured_id ); ?>" class="regular-text" />
                                <p class="description">Enter a WooCommerce product ID to feature on the homepage. Leave blank to hide.</p>
                            </td>
                        </tr>
                    </table>
                    <?php submit_button( 'Save Settings' ); ?>
                </form>
            </div>

            <!-- Demo Import Card -->
            <div class="card" style="padding:24px 28px; border-left: 5px solid #4A2C1A; background:#fff;">
                <h2 style="margin-top:4px; color:#4A2C1A;">📦 Import Demo Data</h2>
                <p style="max-width:640px;">Import sample <strong>products</strong>, <strong>navigation menu</strong>, and <strong>Our Story</strong> page. Perfect for previewing the theme.</p>
                
                <div style="margin: 16px 0;">
                    <button type="button" id="viet-coffee-import-btn" class="button button-primary button-large">
                        <?php echo $imported ? 'Re-Import / Add Missing Demo Data' : 'Import Sample Products, Menu &amp; Story'; ?>
                    </button>
                    <button type="button" id="viet-coffee-reset-btn" class="button button-secondary" style="margin-left:8px;">
                        Reset Demo Data
                    </button>
                </div>
                
                <div id="viet-coffee-import-status" style="margin-top:12px; font-size:14px; min-height:22px;"></div>
                
                <p class="description" style="margin-top:14px;">
                    • Creates 6 sample coffee products with images and categories<br>
                    • Creates or updates the Primary navigation menu<br>
                    • Creates the "Our Story" page used in homepage<br>
                    • Updates hero banner and featured product automatically
                </p>
            </div>
        </div>
    </div>

    <script>
    (function($){
        function showStatus(msg, isError) {
            const $el = $('#viet-coffee-import-status');
            $el.html('<span style="color:' + (isError ? '#b32d2e' : '#2271b1') + '; font-weight:500;">' + msg + '</span>');
        }

        $('#viet-coffee-import-btn').on('click', function(){
            const $btn = $(this);
            $btn.prop('disabled', true).text('Importing...');
            showStatus('Đang nhập dữ liệu demo...');

            $.post(ajaxurl, {
                action: 'viet_coffee_import_demo',
                nonce: '<?php echo wp_create_nonce( "viet_coffee_demo_import" ); ?>'
            }, function(res){
                $btn.prop('disabled', false).text('Re-Import / Add Missing Demo Data');
                if (res.success) {
                    showStatus( res.data || '✅ Demo data imported successfully!' );
                    // Refresh page after short delay so options/IDs update
                    setTimeout(function(){ location.reload(); }, 1600);
                } else {
                    showStatus( '❌ ' + (res.data || 'Import failed.'), true );
                }
            }).fail(function(){
                $btn.prop('disabled', false).text('Re-Import / Add Missing Demo Data');
                showStatus('❌ Network error. Please try again.', true);
            });
        });

        $('#viet-coffee-reset-btn').on('click', function(){
            if (!confirm('This will delete demo products (by SKU prefix), the story page and menu. Continue?')) return;

            const $btn = $(this);
            $btn.prop('disabled', true);
            showStatus('Resetting demo data...');

            $.post(ajaxurl, {
                action: 'viet_coffee_reset_demo',
                nonce: '<?php echo wp_create_nonce( "viet_coffee_demo_import" ); ?>'
            }, function(res){
                $btn.prop('disabled', false);
                if (res.success) {
                    showStatus( res.data || 'Demo data has been removed.' );
                    setTimeout(function(){ location.reload(); }, 1200);
                } else {
                    showStatus( '❌ ' + (res.data || 'Reset failed.'), true );
                }
            }).fail(function(){
                $btn.prop('disabled', false);
                showStatus('❌ Network error during reset.', true);
            });
        });
    })(jQuery);
    </script>
    <?php
}

function viet_coffee_settings_init() {
    register_setting( 'viet_coffee_settings', 'viet_coffee_options' );
    
    add_settings_section(
        'viet_coffee_main_section',
        '',
        null,
        'viet-coffee-settings'
    );
    
    // Featured product field moved into custom page for nicer UI.
}
add_action( 'admin_init', 'viet_coffee_settings_init' );

// ============================================================
// AJAX: Add to Cart
// ============================================================
function viet_coffee_ajax_add_to_cart() {
    check_ajax_referer( 'viet_coffee_nonce', 'nonce' );

    $product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;

    if ( ! $product_id ) {
        wp_send_json_error( array( 'message' => __( 'Invalid product.', 'viet-coffee' ) ) );
    }

    $added = WC()->cart->add_to_cart( $product_id );

    if ( $added ) {
        WC()->cart->calculate_totals();
        wp_send_json_success( array(
            'cart_count' => WC()->cart->get_cart_contents_count(),
            'cart_total' => WC()->cart->get_cart_total(),
        ) );
    } else {
        wp_send_json_error( array( 'message' => __( 'Could not add to cart.', 'viet-coffee' ) ) );
    }
}
add_action( 'wp_ajax_add_to_cart',        'viet_coffee_ajax_add_to_cart' );
add_action( 'wp_ajax_nopriv_add_to_cart', 'viet_coffee_ajax_add_to_cart' );

// ============================================================
// AJAX: Buy Now (empty cart → add product → return checkout URL)
// ============================================================
function viet_coffee_ajax_buy_now() {
    check_ajax_referer( 'viet_coffee_nonce', 'nonce' );

    $product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
    $quantity   = isset( $_POST['quantity'] )   ? absint( $_POST['quantity'] )   : 1;

    if ( ! $product_id ) {
        wp_send_json_error( array( 'message' => __( 'Invalid product.', 'viet-coffee' ) ) );
    }

    WC()->cart->empty_cart();
    $added = WC()->cart->add_to_cart( $product_id, max( 1, $quantity ) );

    if ( $added ) {
        wp_send_json_success( array( 'checkout_url' => wc_get_checkout_url() ) );
    } else {
        wp_send_json_error( array( 'message' => __( 'Could not process Buy Now.', 'viet-coffee' ) ) );
    }
}
add_action( 'wp_ajax_buy_now',        'viet_coffee_ajax_buy_now' );
add_action( 'wp_ajax_nopriv_buy_now', 'viet_coffee_ajax_buy_now' );

// ============================================================
// Buy Now Modal HTML (rendered in wp_footer)
// ============================================================
function viet_coffee_buy_now_modal() {
    ?>
    <div id="buy-now-modal" class="fixed inset-0 z-[9999] hidden" role="dialog" aria-modal="true" aria-labelledby="buy-now-title">
        <div id="buy-now-overlay" class="absolute inset-0 bg-black/60 backdrop-blur-sm cursor-pointer"></div>
        <div class="relative z-10 flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-3xl shadow-2xl w-full max-w-md p-8">
                <div class="flex justify-between items-center mb-6">
                    <h2 id="buy-now-title" class="text-2xl font-bold text-[#4A2C1A]">
                        <?php esc_html_e( 'Xác nhận đặt hàng', 'viet-coffee' ); ?>
                    </h2>
                    <button id="buy-now-close" aria-label="<?php esc_attr_e( 'Close', 'viet-coffee' ); ?>"
                            class="text-gray-400 hover:text-gray-700 text-3xl leading-none">&times;</button>
                </div>

                <p id="buy-now-product-name" class="text-lg font-semibold text-gray-800 mb-1"></p>
                <p id="buy-now-product-price" class="text-amber-700 font-bold text-xl mb-6"></p>

                <div class="flex items-center gap-4 mb-6">
                    <span class="text-gray-600 font-medium"><?php esc_html_e( 'Số lượng:', 'viet-coffee' ); ?></span>
                    <div class="flex items-center border border-gray-200 rounded-xl overflow-hidden select-none">
                        <button id="buy-now-qty-minus"
                                class="px-4 py-2 bg-gray-50 hover:bg-gray-100 text-xl font-bold text-gray-700"
                                aria-label="<?php esc_attr_e( 'Decrease quantity', 'viet-coffee' ); ?>">−</button>
                        <input id="buy-now-qty" type="number" value="1" min="1" max="99"
                               class="w-14 text-center border-none outline-none py-2 font-semibold text-gray-800" />
                        <button id="buy-now-qty-plus"
                                class="px-4 py-2 bg-gray-50 hover:bg-gray-100 text-xl font-bold text-gray-700"
                                aria-label="<?php esc_attr_e( 'Increase quantity', 'viet-coffee' ); ?>">+</button>
                    </div>
                </div>

                <button id="buy-now-confirm"
                        class="w-full bg-[#4A2C1A] hover:bg-[#3a2014] text-white py-4 rounded-2xl font-semibold text-lg transition-colors disabled:opacity-60">
                    <?php esc_html_e( 'Đặt hàng ngay', 'viet-coffee' ); ?>
                </button>
                <p id="buy-now-error" class="text-red-500 text-sm text-center mt-3 hidden"></p>
                <p id="buy-now-loading" class="text-center text-gray-500 text-sm mt-3 hidden">
                    <?php esc_html_e( 'Đang xử lý…', 'viet-coffee' ); ?>
                </p>
            </div>
        </div>
    </div>
    <?php
}
add_action( 'wp_footer', 'viet_coffee_buy_now_modal' );

// ============================================================
// Helper: Reliable way to get mini cart HTML (use native function, not shortcode)
// ============================================================
function viet_coffee_get_mini_cart_html() {
    if ( ! function_exists( 'woocommerce_mini_cart' ) || ! class_exists( 'WooCommerce' ) ) {
        return '<p class="py-8 text-center text-gray-500">Your cart is empty or WooCommerce is not active.</p>';
    }

    // Ensure cart totals are calculated
    if ( WC()->cart ) {
        WC()->cart->calculate_totals();
    }

    ob_start();
    ?>
    <div class="widget_shopping_cart_content">
        <?php woocommerce_mini_cart(); ?>
    </div>
    <?php
    return ob_get_clean();
}

// ============================================================
// Helper: Get full WooCommerce checkout HTML for modal
// ============================================================
function viet_coffee_get_checkout_html() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        return '<p class="py-8 text-center text-gray-500">WooCommerce is not active.</p>';
    }

    if ( WC()->cart && WC()->cart->is_empty() ) {
        return '<div class="text-center py-10">
            <p class="text-lg mb-4">Your cart is empty.</p>
            <button type="button" onclick="document.getElementById(\'checkout-modal\').classList.add(\'hidden\'); document.body.style.overflow=\'\'; if (typeof toggleCartModal === \'function\') toggleCartModal();" class="px-6 py-3 bg-[#4A2C1A] text-white rounded-2xl font-semibold">Return to Cart</button>
        </div>';
    }

    // Always calculate before rendering checkout
    WC()->cart->calculate_totals();

    // Ensure shortcode is registered even in edge-case AJAX or early/late calls.
    if ( ! shortcode_exists( 'woocommerce_checkout' ) && class_exists( 'WC_Shortcodes' ) ) {
        WC_Shortcodes::init();
    }

    ob_start();

    // Use do_shortcode for best compatibility. The standalone woocommerce_checkout() wrapper
    // is not guaranteed in every WC load context (AJAX / footer timing / some setups).
    // Shortcode is registered by WC_Shortcodes on init and always available when WC is active.
    echo do_shortcode( '[woocommerce_checkout]' );

    $output = ob_get_clean();

    // Safety fallback: if shortcode produced almost nothing, try the class directly
    $stripped = trim( wp_strip_all_tags( (string) $output ) );
    if ( strlen( $stripped ) < 30 || strpos( $output, 'woocommerce-checkout' ) === false ) {
        if ( class_exists( 'WC_Shortcode_Checkout' ) ) {
            ob_start();
            WC_Shortcode_Checkout::output( array() );
            $output = ob_get_clean();
        }
    }

    return '<div class="woocommerce-checkout-modal">' . $output . '</div>';
}

// ============================================================
// CART MODAL (for Add to Cart clicks)
// ============================================================
function viet_coffee_cart_modal() {
    // Always render the modal shell.
    ?>
    <div id="cart-modal" class="fixed inset-0 z-[9999] hidden" role="dialog" aria-modal="true">
        <div id="cart-overlay" class="absolute inset-0 bg-black/60 backdrop-blur-sm cursor-pointer"></div>
        <div class="relative z-10 flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden cart-modal-panel">
                <!-- Header -->
                <div class="flex justify-between items-center px-6 py-4 border-b">
                    <h2 class="text-2xl font-bold text-[#4A2C1A]">Your Cart</h2>
                    <button id="cart-close" aria-label="Close cart"
                            class="text-gray-400 hover:text-gray-700 text-3xl leading-none">&times;</button>
                </div>

                <!-- Mini cart content (refreshed on open) -->
                <div id="cart-modal-content" class="p-6 text-sm">
                    <?php echo viet_coffee_get_mini_cart_html(); ?>
                </div>

                <!-- Footer actions -->
                <div class="border-t p-6 bg-[#f8f1e9] flex flex-col sm:flex-row gap-3">
                    <?php if ( class_exists( 'WooCommerce' ) ) : ?>
                        <a href="<?php echo esc_url( wc_get_cart_url() ); ?>"
                           class="flex-1 text-center px-6 py-3 rounded-2xl border border-[#4A2C1A] text-[#4A2C1A] font-semibold hover:bg-white transition-colors">
                            View Cart
                        </a>
                        <button type="button" onclick="closeCartAndOpenCheckout();"
                           class="flex-1 text-center px-6 py-3 rounded-2xl bg-[#4A2C1A] text-white font-semibold hover:bg-black transition-colors">
                            Checkout
                        </button>
                    <?php else : ?>
                        <p class="text-sm text-gray-500">WooCommerce not active.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php
}
add_action( 'wp_footer', 'viet_coffee_cart_modal' );

// AJAX: Return fresh mini-cart HTML for the modal
function viet_coffee_ajax_get_mini_cart() {
    check_ajax_referer( 'viet_coffee_nonce', 'nonce' );

    $html = viet_coffee_get_mini_cart_html();

    wp_send_json_success( $html );
}
add_action( 'wp_ajax_get_mini_cart', 'viet_coffee_ajax_get_mini_cart' );
add_action( 'wp_ajax_nopriv_get_mini_cart', 'viet_coffee_ajax_get_mini_cart' );

// Simple AJAX cart count (for sync after removes in modal etc)
function viet_coffee_ajax_get_cart_count() {
    check_ajax_referer( 'viet_coffee_nonce', 'nonce' );
    wp_send_json_success( array(
        'count' => class_exists('WooCommerce') ? WC()->cart->get_cart_contents_count() : 0,
    ) );
}
add_action( 'wp_ajax_get_cart_count', 'viet_coffee_ajax_get_cart_count' );
add_action( 'wp_ajax_nopriv_get_cart_count', 'viet_coffee_ajax_get_cart_count' );

// ============================================================
// CHECKOUT MODAL + AJAX
// ============================================================
function viet_coffee_checkout_modal() {
    ?>
    <div id="checkout-modal" class="fixed inset-0 z-[9999] hidden" role="dialog" aria-modal="true">
        <div id="checkout-overlay" class="absolute inset-0 bg-black/60 backdrop-blur-sm cursor-pointer"></div>
        <div class="relative z-10 flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-3xl shadow-2xl w-full max-w-5xl overflow-hidden cart-modal-panel checkout-modal-panel">
                <!-- Header -->
                <div class="flex justify-between items-center px-6 py-4 border-b bg-white sticky top-0 z-10">
                    <h2 class="text-2xl font-bold text-[#4A2C1A]">Checkout</h2>
                    <button id="checkout-close" aria-label="Close checkout"
                            class="text-gray-400 hover:text-gray-700 text-3xl leading-none">&times;</button>
                </div>

                <!-- Checkout content (WooCommerce form) -->
                <div id="checkout-modal-content" class="p-6 md:p-8 text-sm overflow-auto" style="max-height: 72vh;">
                    <?php echo viet_coffee_get_checkout_html(); ?>
                </div>

                <!-- Simple footer note / back action -->
                <div class="border-t p-4 bg-[#f8f1e9] flex items-center justify-between text-sm">
                    <button type="button" onclick="closeCheckoutAndOpenCart();"
                            class="px-4 py-2 text-[#4A2C1A] hover:underline font-medium flex items-center gap-2">
                        <span>&larr;</span> Back to Cart
                    </button>
                    <span class="text-gray-500 text-xs">Secure checkout powered by WooCommerce</span>
                </div>
            </div>
        </div>
    </div>
    <?php
}
add_action( 'wp_footer', 'viet_coffee_checkout_modal' );

// AJAX: Return fresh checkout HTML
function viet_coffee_ajax_get_checkout() {
    check_ajax_referer( 'viet_coffee_nonce', 'nonce' );

    // Make sure cart is ready in AJAX context
    if ( class_exists( 'WooCommerce' ) && WC()->cart ) {
        WC()->cart->calculate_totals();
    }

    $html = viet_coffee_get_checkout_html();

    wp_send_json_success( $html );
}
add_action( 'wp_ajax_get_checkout', 'viet_coffee_ajax_get_checkout' );
add_action( 'wp_ajax_nopriv_get_checkout', 'viet_coffee_ajax_get_checkout' );

// ============================================================
// SEARCH MODAL (simple, invoked by header button)
// ============================================================
function viet_coffee_search_modal() {
    ?>
    <div id="search-modal" class="fixed inset-0 z-[9999] hidden" role="dialog">
        <div id="search-overlay" class="absolute inset-0 bg-black/50"></div>
        <div class="relative z-10 flex items-start justify-center pt-24 p-4">
            <div class="bg-white rounded-3xl shadow-2xl w-full max-w-md p-4">
                <form id="site-search-form" action="/" method="get" class="flex gap-2">
                    <input type="hidden" name="post_type" value="product">
                    <input type="text" name="s" id="site-search-input"
                           class="flex-1 border border-gray-300 focus:border-[#4A2C1A] outline-none rounded-2xl px-5 py-3 text-lg"
                           placeholder="Search coffees..." autocomplete="off">
                    <button type="submit"
                            class="px-6 rounded-2xl bg-[#4A2C1A] text-white font-semibold">Search</button>
                </form>
                <div class="text-right mt-2">
                    <button id="search-close" class="text-xs text-gray-500 hover:text-gray-700">ESC to close</button>
                </div>
            </div>
        </div>
    </div>
    <?php
}
add_action( 'wp_footer', 'viet_coffee_search_modal' );

// ============================================================
// DEMO DATA IMPORT SYSTEM
// ============================================================

/**
 * Helper: Download remote image and attach to a post.
 */
function viet_coffee_sideload_image( $url, $post_id = 0, $desc = '' ) {
    if ( ! function_exists( 'media_handle_sideload' ) ) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
    }

    $tmp = download_url( $url );
    if ( is_wp_error( $tmp ) ) {
        return 0;
    }

    $file_array = array(
        'name'     => wp_basename( $url ) . '.jpg',
        'tmp_name' => $tmp,
    );

    $attachment_id = media_handle_sideload( $file_array, $post_id, $desc );

    if ( is_wp_error( $attachment_id ) ) {
        @unlink( $tmp );
        return 0;
    }

    return $attachment_id;
}

/**
 * Create / update product categories.
 */
function viet_coffee_ensure_product_categories() {
    $cats = array(
        'single-origin' => 'Single Origin',
        'blends'        => 'Blends',
        'premium'       => 'Premium',
    );

    $ids = array();
    foreach ( $cats as $slug => $name ) {
        $term = get_term_by( 'slug', $slug, 'product_cat' );
        if ( ! $term ) {
            $res = wp_insert_term( $name, 'product_cat', array( 'slug' => $slug ) );
            if ( ! is_wp_error( $res ) ) {
                $ids[ $slug ] = (int) $res['term_id'];
            }
        } else {
            $ids[ $slug ] = (int) $term->term_id;
        }
    }
    return $ids;
}

/**
 * Main import logic. Idempotent (skips products with existing SKU).
 */
function viet_coffee_do_import_demo_data() {
    if ( ! class_exists( 'WC_Product_Simple' ) ) {
        return new WP_Error( 'no_woo', 'WooCommerce is required to import products.' );
    }

    $created_products = 0;
    $cat_ids = viet_coffee_ensure_product_categories();

    // Sample products
    $products_data = array(
        array(
            'name'         => 'Robusta Buôn Ma Thuột 250g',
            'sku'          => 'vcf-robusta-bmt-250',
            'price'        => '12.50',
            'short_desc'   => 'Hương vị đậm đà, đắng nhẹ đặc trưng của robusta Việt Nam. Ghi chú socola đen và hạt.',
            'description'  => 'Cà phê Robusta từ vùng đất đỏ bazan Buôn Ma Thuột nổi tiếng. Hạt được chọn lọc kỹ càng, rang vừa để giữ nguyên hương vị mạnh mẽ, phù hợp pha phin truyền thống hoặc espresso.',
            'image'        => 'https://picsum.photos/id/201/800/800',
            'cats'         => array( 'single-origin' ),
        ),
        array(
            'name'         => 'Arabica Đà Lạt 250g',
            'sku'          => 'vcf-arabica-dl-250',
            'price'        => '15.90',
            'short_desc'   => 'Hương hoa nhài, vị chua thanh và ngọt hậu. Arabica thượng hạng từ cao nguyên Lâm Đồng.',
            'description'  => 'Được trồng ở độ cao 1500m tại Đà Lạt. Hạt Arabica có hương vị tinh tế, axit nhẹ nhàng, lý tưởng cho drip, pour-over hoặc cold brew.',
            'image'        => 'https://picsum.photos/id/29/800/800',
            'cats'         => array( 'single-origin' ),
        ),
        array(
            'name'         => 'Cà Phê Chồn Weasel 100g',
            'sku'          => 'vcf-weasel-100',
            'price'        => '45.00',
            'short_desc'   => 'Loại cà phê hiếm và đắt nhất thế giới. Hương vị mượt mà, ít đắng, hậu vị kéo dài.',
            'description'  => 'Cà phê được chế biến qua hệ tiêu hóa của chồn hương. Quy trình tự nhiên tạo ra hương vị độc đáo, mượt mà không thể nhầm lẫn. Số lượng giới hạn.',
            'image'        => 'https://picsum.photos/id/312/800/800',
            'cats'         => array( 'premium' ),
        ),
        array(
            'name'         => 'Vietnam Espresso Blend 500g',
            'sku'          => 'vcf-espresso-500',
            'price'        => '18.90',
            'short_desc'   => 'Sự kết hợp hoàn hảo giữa Robusta và Arabica. Tạo lớp crema dày và vị cân bằng.',
            'description'  => 'Blend chuyên dụng cho máy espresso hoặc pha phin mạnh. Hương socola, hạt và chút trái cây. Tỷ lệ 60% Robusta + 40% Arabica.',
            'image'        => 'https://picsum.photos/id/160/800/800',
            'cats'         => array( 'blends' ),
        ),
        array(
            'name'         => 'Cao Nguyên Medium Roast 250g',
            'sku'          => 'vcf-highland-250',
            'price'        => '11.00',
            'short_desc'   => 'Hương caramel, hạt rang vừa phải. Phù hợp uống hàng ngày cho mọi người.',
            'description'  => 'Cà phê rang vừa từ vùng cao nguyên, mang đến sự cân bằng giữa đắng và chua. Dễ uống, phù hợp cả hot brew và cold brew.',
            'image'        => 'https://picsum.photos/id/251/800/800',
            'cats'         => array( 'blends' ),
        ),
        array(
            'name'         => 'Bộ Sampler 4 Vị Cà Phê',
            'sku'          => 'vcf-sampler-4',
            'price'        => '16.50',
            'short_desc'   => 'Thử 4 loại cà phê đặc sản. Bao gồm Robusta, Arabica, Blend và một loại đặc biệt.',
            'description'  => 'Bộ sưu tập mini 4x50g. Hoàn hảo để khám phá các hương vị khác nhau của cà phê Việt Nam. Kèm hướng dẫn pha nhanh.',
            'image'        => 'https://picsum.photos/id/133/800/800',
            'cats'         => array( 'premium' ),
        ),
    );

    $first_product_id = 0;

    foreach ( $products_data as $data ) {
        $existing_id = wc_get_product_id_by_sku( $data['sku'] );
        if ( $existing_id ) {
            if ( ! $first_product_id ) {
                $first_product_id = $existing_id;
            }
            continue;
        }

        $product = new WC_Product_Simple();
        $product->set_name( $data['name'] );
        $product->set_sku( $data['sku'] );
        $product->set_regular_price( $data['price'] );
        $product->set_short_description( $data['short_desc'] );
        $product->set_description( $data['description'] );
        $product->set_status( 'publish' );
        $product->set_catalog_visibility( 'visible' );
        $product->set_stock_status( 'instock' );
        $product->set_manage_stock( false );

        // Categories
        $term_ids = array();
        foreach ( $data['cats'] as $slug ) {
            if ( isset( $cat_ids[ $slug ] ) ) {
                $term_ids[] = $cat_ids[ $slug ];
            }
        }
        if ( ! empty( $term_ids ) ) {
            $product->set_category_ids( $term_ids );
        }

        $product_id = $product->save();

        if ( $product_id ) {
            // Attach image
            $img_id = viet_coffee_sideload_image( $data['image'], $product_id, $data['name'] );
            if ( $img_id ) {
                $product->set_image_id( $img_id );
                $product->save();
            }

            $created_products++;

            if ( ! $first_product_id ) {
                $first_product_id = $product_id;
            }
        }
    }

    // Create / update Our Story page
    $story_page = get_page_by_path( 'our-story' );
    $story_content = viet_coffee_get_story_content();

    if ( $story_page ) {
        wp_update_post( array(
            'ID'           => $story_page->ID,
            'post_content' => $story_content,
            'post_status'  => 'publish',
        ) );
        $story_id = $story_page->ID;
    } else {
        $story_id = wp_insert_post( array(
            'post_title'   => 'Our Story',
            'post_name'    => 'our-story',
            'post_content' => $story_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ) );
    }

    // Set featured image for story page if none
    if ( $story_id && ! get_post_thumbnail_id( $story_id ) ) {
        $story_img = viet_coffee_sideload_image( 'https://picsum.photos/id/1016/1200/800', $story_id, 'Our Story' );
        if ( $story_img ) {
            set_post_thumbnail( $story_id, $story_img );
        }
    }

    // Create / replace Primary Menu
    viet_coffee_setup_primary_menu( $story_id );

    // Set featured product
    $opts = get_option( 'viet_coffee_options', array() );
    if ( $first_product_id ) {
        $opts['featured_product_id'] = $first_product_id;
        update_option( 'viet_coffee_options', $opts );
    }

    // Hero settings
    set_theme_mod( 'hero_title', 'AUTHENTIC VIETNAMESE COFFEE' );
    set_theme_mod( 'hero_subtitle', 'Single-origin beans from Vietnam\'s finest highlands. Freshly roasted with passion and delivered worldwide.' );
    set_theme_mod( 'hero_background', 'https://picsum.photos/id/1016/2000/1200' );

    update_option( 'viet_coffee_demo_imported', true );

    $msg = sprintf(
        '✅ Demo import complete. Created %d new products. Story page & menu ready.',
        $created_products
    );

    return $msg;
}

/**
 * Beautiful story content (Vietnamese + English flavor).
 */
function viet_coffee_get_story_content() {
    return '
<div class="max-w-4xl mx-auto px-2">
    <div class="mb-10">
        <span class="inline-block px-5 py-1 bg-amber-100 text-amber-800 rounded-full text-sm font-medium tracking-wider">OUR HERITAGE</span>
        <h2 class="text-4xl md:text-5xl heading-font font-bold text-[#4A2C1A] mt-4 mb-6">Từ Cao Nguyên Việt Nam Đến Tách Cà Phê Của Bạn</h2>
    </div>

    <div class="prose prose-lg max-w-none text-gray-700">
        <p class="text-xl">Chúng tôi là những người con của đất Việt, đam mê mang tinh hoa cà phê Việt Nam đến với thế giới.</p>

        <p>Chúng tôi làm việc trực tiếp với những nông dân tại <strong>Buôn Ma Thuột</strong>, <strong>Đà Lạt</strong> và các vùng cao nguyên trứ danh khác. Mỗi hạt cà phê đều được chọn lọc kỹ lưỡng, thu hoạch đúng mùa và chế biến theo phương pháp truyền thống kết hợp công nghệ hiện đại.</p>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 my-10 not-prose">
            <div class="p-6 bg-[#f8f1e9] rounded-2xl">
                <div class="text-3xl mb-3">🌿</div>
                <h4 class="font-semibold text-lg mb-1 text-[#4A2C1A]">Direct Trade</h4>
                <p class="text-sm">Hợp tác công bằng, giá cao hơn cho nông dân và chất lượng vượt trội cho bạn.</p>
            </div>
            <div class="p-6 bg-[#f8f1e9] rounded-2xl">
                <div class="text-3xl mb-3">☕</div>
                <h4 class="font-semibold text-lg mb-1 text-[#4A2C1A]">Small Batch Roast</h4>
                <p class="text-sm">Rang thủ công theo mẻ nhỏ mỗi ngày để giữ trọn vẹn hương vị tươi mới.</p>
            </div>
            <div class="p-6 bg-[#f8f1e9] rounded-2xl">
                <div class="text-3xl mb-3">🌍</div>
                <h4 class="font-semibold text-lg mb-1 text-[#4A2C1A]">Global Delivery</h4>
                <p class="text-sm">Đóng gói chuyên nghiệp và giao hàng nhanh chóng đến mọi nơi trên thế giới.</p>
            </div>
        </div>

        <p>Từ những hạt Robusta mạnh mẽ của Buôn Ma Thuột đến Arabica tinh tế Đà Lạt, và cả Cà Phê Chồn huyền thoại – mỗi sản phẩm đều kể một câu chuyện về vùng đất, con người và niềm tự hào Việt Nam.</p>

        <p class="text-lg font-medium text-[#4A2C1A]">Uống một tách – cảm nhận một đất nước.</p>
    </div>
</div>';
}

/**
 * Create primary navigation menu with links.
 */
function viet_coffee_setup_primary_menu( $story_page_id = 0 ) {
    $menu_name = 'Viet Coffee Primary';
    $menu = wp_get_nav_menu_object( $menu_name );

    if ( $menu ) {
        wp_delete_nav_menu( $menu->term_id );
    }

    $menu_id = wp_create_nav_menu( $menu_name );

    if ( is_wp_error( $menu_id ) ) {
        return;
    }

    // Products (scroll to collection on front page)
    wp_update_nav_menu_item( $menu_id, 0, array(
        'menu-item-title'  => 'Shop',
        'menu-item-url'    => home_url( '/#products' ),
        'menu-item-status' => 'publish',
        'menu-item-type'   => 'custom',
    ) );

    // Our Story (scroll to inline story section)
    wp_update_nav_menu_item( $menu_id, 0, array(
        'menu-item-title'  => 'Our Story',
        'menu-item-url'    => home_url( '/#stories' ),
        'menu-item-status' => 'publish',
        'menu-item-type'   => 'custom',
    ) );

    // Contact (anchor)
    wp_update_nav_menu_item( $menu_id, 0, array(
        'menu-item-title'  => 'Contact',
        'menu-item-url'    => home_url( '/#contact' ),
        'menu-item-status' => 'publish',
        'menu-item-type'   => 'custom',
    ) );

    // Assign to primary location
    $locations = get_theme_mod( 'nav_menu_locations', array() );
    $locations['primary'] = $menu_id;
    set_theme_mod( 'nav_menu_locations', $locations );
}

/**
 * AJAX: Run the import.
 */
function viet_coffee_ajax_import_demo() {
    check_ajax_referer( 'viet_coffee_demo_import', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Bạn không có quyền thực hiện thao tác này.' );
    }

    $result = viet_coffee_do_import_demo_data();

    if ( is_wp_error( $result ) ) {
        wp_send_json_error( $result->get_error_message() );
    }

    wp_send_json_success( $result );
}
add_action( 'wp_ajax_viet_coffee_import_demo', 'viet_coffee_ajax_import_demo' );

/**
 * AJAX: Reset demo data (products by SKU prefix, story page, menu).
 */
function viet_coffee_ajax_reset_demo() {
    check_ajax_referer( 'viet_coffee_demo_import', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permission denied.' );
    }

    $deleted = 0;

    // Delete products with our SKU prefix
    $skus = array( 'vcf-robusta-bmt-250', 'vcf-arabica-dl-250', 'vcf-weasel-100', 'vcf-espresso-500', 'vcf-highland-250', 'vcf-sampler-4' );
    foreach ( $skus as $sku ) {
        $pid = wc_get_product_id_by_sku( $sku );
        if ( $pid ) {
            wp_delete_post( $pid, true ); // force delete
            $deleted++;
        }
    }

    // Delete story page
    $story = get_page_by_path( 'our-story' );
    if ( $story ) {
        wp_delete_post( $story->ID, true );
    }

    // Remove primary menu we created
    $menu = wp_get_nav_menu_object( 'Viet Coffee Primary' );
    if ( $menu ) {
        wp_delete_nav_menu( $menu->term_id );
    }

    delete_option( 'viet_coffee_demo_imported' );

    wp_send_json_success( 'Demo data removed (' . $deleted . ' products). Refresh to see changes.' );
}
add_action( 'wp_ajax_viet_coffee_reset_demo', 'viet_coffee_ajax_reset_demo' );
?>